<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>comment</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>85074f6d-9ec7-4033-b34f-2bdcf5bbdfaf</testSuiteGuid>
   <testCaseLink>
      <guid>b56b7c7b-6da5-4c63-8a7a-56bb9f58da53</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/comment</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>5779e545-ae39-45ae-8524-c1f03a68aac9</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/comment</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>5779e545-ae39-45ae-8524-c1f03a68aac9</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>comment</value>
         <variableId>dfa691fd-eb3f-494d-b472-d68720f2aa75</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
