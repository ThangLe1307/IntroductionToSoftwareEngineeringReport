<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>birthdate</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>152eee79-de08-4df6-a932-c76c60987447</testSuiteGuid>
   <testCaseLink>
      <guid>6ea14171-80dc-48e3-b943-ada2f5aa280b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit Birthday</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>9c75632f-0dbc-4a13-9130-b03e39b314f6</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/birthdate</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>9c75632f-0dbc-4a13-9130-b03e39b314f6</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>date</value>
         <variableId>5c426d0f-b2c0-413e-bde6-09dc4eb44d46</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
