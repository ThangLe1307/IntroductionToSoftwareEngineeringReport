<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuit2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ba59385b-6595-4f56-a252-009821e2871d</testSuiteGuid>
   <testCaseLink>
      <guid>fc60b439-182a-4f94-b03d-efc810a89615</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Invalid OTP</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>bff1c2ba-2ece-45c5-9534-0f23a74cb152</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/TestData2</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>bff1c2ba-2ece-45c5-9534-0f23a74cb152</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>phone</value>
         <variableId>2ba58244-29bc-41aa-9550-286c39327f99</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
