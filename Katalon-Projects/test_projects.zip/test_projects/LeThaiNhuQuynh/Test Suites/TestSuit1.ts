<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuit1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>64d69870-46d7-4e8b-9cbf-6fdcdcd99297</testSuiteGuid>
   <testCaseLink>
      <guid>8fa36dd7-2f9f-4c46-80fa-a76ca0aebf27</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Invalid phone number</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>6a7bc73e-f69c-4c85-ac16-37e265d60872</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/TestData1</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>6a7bc73e-f69c-4c85-ac16-37e265d60872</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>phone</value>
         <variableId>04ce4af2-ca46-4f62-b26d-7766d4554572</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
