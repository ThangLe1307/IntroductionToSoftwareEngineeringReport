<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuit4</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>859e7715-bbd5-45a3-8adc-3f08ac7a82b3</testSuiteGuid>
   <testCaseLink>
      <guid>ccb8fde2-3e3e-4ce1-b1b6-1d939a882c13</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Valid OTP</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>44410a1f-7c92-435a-bfa3-f2f446408dc7</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/TestData2</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>44410a1f-7c92-435a-bfa3-f2f446408dc7</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>phone</value>
         <variableId>6474e9b2-e6f4-46a4-8315-7b39d65ea308</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
