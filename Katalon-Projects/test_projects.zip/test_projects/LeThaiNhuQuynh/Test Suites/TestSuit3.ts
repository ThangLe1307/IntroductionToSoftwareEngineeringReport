<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuit3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>a894e40d-04c1-4b38-9f2e-759fdb72deb6</testSuiteGuid>
   <testCaseLink>
      <guid>0c0140b2-57b9-434d-a061-29516a8a7144</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Edit Username</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>b0831ff6-0458-43d4-8b68-5b599ae6194d</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/TestData3</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>b0831ff6-0458-43d4-8b68-5b599ae6194d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>1036861e-9e32-45b0-aa5d-6a6cf4b54a57</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
