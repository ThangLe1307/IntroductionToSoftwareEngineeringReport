<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SearchingTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>0f586c77-4b25-4283-963c-1a669e25c2f1</testSuiteGuid>
   <testCaseLink>
      <guid>b92660dc-21a9-4078-ae9e-ce6a79f0b950</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/searching</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>a00982c2-9ec8-4a9c-88e5-45a9c775a838</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/key1</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>a00982c2-9ec8-4a9c-88e5-45a9c775a838</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>key</value>
         <variableId>bc849218-2c83-499c-bd80-92285b13b0d8</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
