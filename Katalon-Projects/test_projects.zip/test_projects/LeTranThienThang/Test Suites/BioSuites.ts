<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>BioSuites</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>e3a05245-96db-4bb6-9055-510d1d08793f</testSuiteGuid>
   <testCaseLink>
      <guid>8b3174af-72c6-45c4-a637-b6750af1c406</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UpdateBio</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>9330f3f6-5c7e-4bde-88e2-05c78aad2475</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/bio</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>9330f3f6-5c7e-4bde-88e2-05c78aad2475</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>bio</value>
         <variableId>53c73677-55a8-43ee-90d3-f9c14c5176d2</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
